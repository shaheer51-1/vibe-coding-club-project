# 01_OVERVIEW.md - Project Overview & Executive Summary

## 1. Product Vision
**VibeCraft** is an interactive, spec-driven development workbench engineered for the modern "Vibe Coding" paradigm. In accordance with the methodology taught in the **Vibe Coding Club**, this application demonstrates how developers transition from blind prompt iteration ("cascade fatigue") into structured, deterministic AI engineering through comprehensive markdown specifications.

Rather than treating AI code generation as unstructured guessing, VibeCraft anchors large language models (LLMs) with eight synchronized specification files. The application itself is the living, production-ready realization of these eight specifications.

---

## 2. Problem Statement
First- and second-semester computer science students and emerging developers frequently encounter three primary roadblocks when adopting AI-assisted coding tools (Cursor, Claude, Copilot, Gemini):
1. **Context Fragmentation**: AI models forget previous decisions across long chat sessions, leading to hallucinated APIs and conflicting architectural patterns.
2. **Cascade Fatigue**: Spending hours in iterative "fix this / no, fix that" loops without an established technical blueprint.
3. **Lack of Process Discipline**: Coding before designing specifications leads to untestable, fragile software with no clear business logic or UX invariants.

---

## 3. The Vibe Coding Club 8-Markdown Methodology
Our workflow enforces an architectural sequence where natural language intent is crystallized into eight modular documents before and alongside code generation:

| Order | Document | Purpose & AI Instruction Role |
| :--- | :--- | :--- |
| **01** | `01_OVERVIEW.md` | Executive vision, problem statement, KPIs, and scope boundaries |
| **02** | `02_FEATURES.md` | Persona definition, P0/P1/P2 priorities, Given/When/Then acceptance criteria |
| **03** | `03_ARCHITECTURE.md` | Component hierarchy, data contracts, state lifecycle, and schemas |
| **04** | `04_DESIGN.md` | Design tokens, zero-pill discipline, spatial math, and WCAG AA standards |
| **05** | `05_USER_FLOW.md` | State machine transitions, decision trees, and screen walkthroughs |
| **06** | `06_ROADMAP.md` | Phased milestone deliverables, tech debt mitigation, and Definition of Done |
| **07** | `07_BUSINESS_MODEL.md` | Unit economics, token cost models, value propositions, and sustainability |
| **08** | `08_TESTING_PLAN.md` | Automated test suites, edge case matrices, and prompt regression gates |

---

## 4. Key Performance Indicators (KPIs)
- **100% Spec Coverage**: Every UI view, state hook, and business calculation corresponds directly to specifications in files 01 through 08.
- **Sub-50ms Interaction Latency**: Pure client-side reactivity with zero unneeded roundtrips.
- **Zero Pill / Anti-Slop Compliance**: 100% adherence to typography-driven UI, eliminating generic purple gradient bubbles.
- **One-Click Export**: Instant zip packaging and raw copy for all 8 markdown files.
- **Automated Test Pass Rate**: 100% of defined unit, integration, and prompt regression tests pass in the live testing runner.

---

## 5. Scope & Boundary Matrix
- **In-Scope**:
  - Live interactive explorer for all 8 specifications.
  - Interactive workbench modules (Design Token Inspector, Architecture Topology, User Flow Simulator, Sprint Kanban, Unit Economics Calculator, and Live Test Harness).
  - Markdown editor, syntax highlighter, and download suite (.zip + single .md files).
  - GitHub upload helper with shell scripts and validation checks.
- **Out-of-Scope (V1)**:
  - Multi-tenant backend databases requiring external paid authentication providers.
  - Native mobile compilation (web viewport responsive down to mobile viewports).
