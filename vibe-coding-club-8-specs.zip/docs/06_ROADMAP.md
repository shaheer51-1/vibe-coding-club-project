# 06_ROADMAP.md - Milestone Roadmap & Tech Debt Strategy

## 1. Milestone Sprints

### Sprint 1: Foundation & Spec Engineering (Completed)
- **Goal**: Establish the canonical 8-markdown specification architecture and core application layout.
- **Deliverables**:
  - Authoring of all 8 markdown documents (`01_OVERVIEW.md` through `08_TESTING_PLAN.md`).
  - Strict TypeScript configurations and zero-pill UI foundation.
  - Spec Hub interface with formatted markdown rendering and search.

### Sprint 2: Interactive Engineering Modules (Completed)
- **Goal**: Implement the live, functional realization of the specifications so the app is a working project, not just static text.
- **Deliverables**:
  - Live Architecture Topology node graph with simulated health pinging.
  - Interactive User Flow Finite State Machine simulator.
  - Design Token Playground with live WCAG AA contrast analysis and font scaler.
  - Interactive Sprint Kanban Board with state toggles.
  - Unit Economics & Token Burn Rate calculator.
  - In-browser Automated Test Runner with runnable assertion suites.

### Sprint 3: Export & Submission Suite (Completed)
- **Goal**: Streamline deliverable export and GitHub hand-off for Vibe Coding Club members.
- **Deliverables**:
  - High-speed client-side ZIP packaging using JSZip.
  - Single-file markdown download triggers.
  - Dynamic GitHub CLI shell command generator with repo validation.
  - Assignment Deliverables Checklist with real-time pass/fail states.

### Sprint 4: Advanced Tooling & Polish (Current)
- **Goal**: Provide customizable document editing and AI spec generation helper.
- **Deliverables**:
  - In-browser markdown editor with draft persistence in LocalStorage.
  - AI Prompt Scaffold Generator for generating future projects.
  - Keyboard shortcuts (`Ctrl/Cmd + K` search, `Ctrl/Cmd + E` export).

---

## 2. Technical Debt Mitigation Plan

| Debt Item | Risk Level | Mitigation Strategy | Target Resolution |
| :--- | :--- | :--- | :--- |
| **Large LocalStorage Payload** | Low | Store diffs or compressed document strings rather than full text duplicates. | Sprint 4 |
| **Markdown Parser Boundary** | Medium | Use robust sanitizing regex parser for markdown preview without bundling heavy external AST trees. | Sprint 2 (Done) |
| **Mobile Screen Real Estate** | Medium | Collapse sidebar on screens `< 768px` into a clean sheet overlay. | Sprint 3 (Done) |

---

## 3. Definition of Done (DoD)
A feature or milestone is considered **Done** only when:
1. **Spec Alignment**: Code adheres directly to criteria in `02_FEATURES.md` and `04_DESIGN.md`.
2. **TypeScript Compilation**: `npm run lint` / `tsc --noEmit` passes with 0 errors.
3. **Automated Testing**: 100% of tests in `08_TESTING_PLAN.md` execute and pass.
4. **Zero-Pill Compliance**: No static pill capsules or generic AI gradient slop present.
5. **Clean Git State**: Code is committed with structured semantic messages (`feat:`, `fix:`, `docs:`).
