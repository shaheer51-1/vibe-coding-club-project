# 04_DESIGN.md - UI/UX Design System & Anti-Slop Guidelines

## 1. Design Philosophy: Intentional Developer Tooling
VibeCraft strictly follows the **Frontend Design Constitution** to eliminate generic "AI slop" (purple gradients, rounded pill capsules, low-contrast text, dead click buttons). The visual language is that of a disciplined engineering workbench:
- Crisp high-contrast monochrome base (`zinc-900` / `zinc-950` dark backgrounds or clean `slate-50` / `white` light panels).
- Intentional accent colors used sparingly for functional indicators: Emerald (`#10b981`) for passing tests/active nodes, Amber (`#f59e0b`) for pending/warning states, and Cyan (`#06b6d4`) for interactive triggers.
- Typographic density: Monospace numerals, clear hierarchies, and subtle typographic dividers (`·` and `/`) instead of colorful bubble badges.

---

## 2. Zero-Pill & Metadata Discipline Rules
1. **Never wrap static text in pill capsules**:
   - ❌ *Don't*: `<span className="bg-purple-100 rounded-full px-3 py-1">P0 Must Have</span>`
   - ✅ *Do*: `<span className="font-mono text-xs text-amber-500 font-semibold tracking-wide">P0 · MUST-HAVE</span>`
2. **Metadata Separators**:
   - Use quiet unboxed text: `Author: Vibe Club · Updated: Sunday · 8 Files Ready`
3. **Interactive Controls Only**:
   - Segmented buttons and tabs have functional `<button>` states with subtle background contrast, not garish candy badges.

---

## 3. Color Tokens & Palette

| Token Role | Hex Code | Tailwind Equivalent | Usage |
| :--- | :--- | :--- | :--- |
| **Surface Dark** | `#09090b` | `zinc-950` | Primary app background |
| **Surface Raised** | `#18181b` | `zinc-900` | Card & workbench container surfaces |
| **Surface Border** | `#27272a` | `zinc-800` | 1px clean crisp borders |
| **Text Primary** | `#fafafa` | `zinc-50` | Headings, document titles, primary text |
| **Text Secondary** | `#a1a1aa` | `zinc-400` | Explanatory copy, markdown body text |
| **Text Muted** | `#71717a` | `zinc-500` | Labels, timestamps, file sizes |
| **Accent Emerald** | `#10b981` | `emerald-500` | Passing tests, ready status, success prompts |
| **Accent Amber** | `#f59e0b` | `amber-500` | Warnings, P0 priorities, active state nodes |
| **Accent Cyan** | `#06b6d4` | `cyan-500` | Selected active documents, code highlights |

---

## 4. Typography Scale

| Style | Font Family | Size | Weight | Tracking / Leading |
| :--- | :--- | :--- | :--- | :--- |
| **Display Header** | Inter / System Sans | 24px (1.5rem) | Bold (700) | `-0.02em`, `1.2` |
| **Section Title** | Inter / System Sans | 18px (1.125rem) | SemiBold (600) | `-0.01em`, `1.3` |
| **Body Standard** | Inter / System Sans | 14px (0.875rem) | Regular (400) | `normal`, `1.5` |
| **Metadata / Micro** | Inter / System Sans | 12px (0.75rem) | Medium (500) | `0.02em`, `1.4` |
| **Code / Syntax** | JetBrains Mono / SF Mono | 13px (0.8125rem) | Regular (400) | `tight`, `1.6` |

---

## 5. Spatial & Radius Mathematics
- **Padding Formula**: Outer container padding $\ge$ inner padding between children ($P_{\text{outer}} = 20\text{px}$, $P_{\text{inner}} = 12\text{px}$).
- **Button Padding**: Horizontal padding is approximately double vertical padding (`py-2 px-4` or `py-1.5 px-3`).
- **Radius Harmony**: $r_{\text{inner}} = r_{\text{outer}} - \text{padding}$.
  - Outer card $r = 12\text{px}$ (`rounded-xl`), inner element $r = 8\text{px}$ (`rounded-lg`).

---

## 6. Accessibility (WCAG 2.1 AA) Compliance
- All text meets minimum 4.5:1 contrast against its background.
- Interactive controls include clear `:focus-visible` outlines (`ring-2 ring-cyan-500/50`).
- No critical information is conveyed by color alone; every status includes an icon or textual label.
- Keyboard navigation is fully supported across all tabs, files, and modal dialogues.
