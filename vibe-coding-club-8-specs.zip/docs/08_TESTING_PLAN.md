# 08_TESTING_PLAN.md - Testing Strategy, Quality Gates & Verification Matrix

## 1. Testing Philosophy
In the Vibe Coding paradigm, code is generated rapidly by LLMs, which makes automated verification and quality gates paramount. Every feature specified in `02_FEATURES.md` and designed in `04_DESIGN.md` must pass automated validation before deployment.

---

## 2. Test Suite Architecture

```
+--------------------------------------------------------------------------+
|                          TEST SUITE MATRIX                               |
+-------------------+--------------------+---------------------------------+
| Test Level        | Target Scope       | Tools / Verification Engine     |
+-------------------+--------------------+---------------------------------+
| Level 1: Unit     | Pure functions &   | In-Browser Assertion Harness    |
|                   | mathematical math  | (testEngine.ts)                 |
+-------------------+--------------------+---------------------------------+
| Level 2: State    | State transitions  | Finite State Simulator &        |
|                   | & User Flows       | Lifecycle Assertion Hook        |
+-------------------+--------------------+---------------------------------+
| Level 3: Design   | Zero-Pill Rules &  | Token Validator & WCAG AA       |
|                   | Typography checks  | Contrast Math Ratio Engine      |
+-------------------+--------------------+---------------------------------+
| Level 4: Spec QA  | Deliverable status | 8-File Integrity Checker &      |
|                   | & ZIP packaging    | JSZip In-Memory Validation      |
+--------------------------------------------------------------------------+
```

---

## 3. Automated Test Cases & Assertions

### Suite A: Spec Hub & Integrity Tests
- **TEST-01 [Unit]**: Verify all 8 markdown documents exist with non-empty content and valid headers.
  - *Expected*: Exactly 8 documents loaded, each containing $> 500$ characters and matching filenames `01_OVERVIEW.md` through `08_TESTING_PLAN.md`.
- **TEST-02 [Unit]**: Verify ZIP archive generator produces valid compressed archive containing all 8 documents.
  - *Expected*: `zip.file()` matches all 8 filenames; generated Blob size $> 5\text{KB}$.

### Suite B: Interactive Workbench & State Engine Tests
- **TEST-03 [State Machine]**: User Flow Simulator advances through valid states without orphan loops.
  - *Expected*: Initial state `Drafting` transition to `Prompting` -> `Testing` -> `Passed` -> `Complete`.
- **TEST-04 [Economics Calc]**: Unit economics cost model computes accurate token savings.
  - *Expected*: Given input 180k tokens vs 35k tokens, calculated cost delta equals 75.4% $\pm 0.5\%$.
- **TEST-05 [Architecture Topology]**: Verify all 5 system nodes report `ONLINE` health status.
  - *Expected*: Nodes (UI, Spec State, Test Engine, Zip Bundler, LocalStorage) pass latency check $< 15\text{ms}$.

### Suite C: Design System & Anti-Slop Rules Tests
- **TEST-06 [Contrast Ratio]**: Ensure text colors meet WCAG AA minimum 4.5:1 ratio against background.
  - *Expected*: `#fafafa` on `#09090b` calculates to $18.4:1$ (Passes AAA & AA).
- **TEST-07 [Zero-Pill Compliance]**: Verify metadata labels render as typographic text without rounded capsule enclosures.
  - *Expected*: Zero pill enclosure classes detected on static metadata spans.

### Suite D: GitHub Submission Suite Tests
- **TEST-08 [Integration]**: Dynamic CLI generator creates valid Bash script for specified student GitHub repo.
  - *Expected*: Generates syntax-valid `git remote add origin https://github.com/{user}/{repo}.git`.

---

## 4. Quality Gates for Release
To consider the Vibe Coding Club deliverable complete:
1. `npm run build` succeeds without syntax or bundle errors.
2. `npm run lint` / `tsc --noEmit` exits with status `0`.
3. In-app test runner displays `8 of 8 Test Suites Passing (100%)`.
4. ZIP export unpacks cleanly on local filesystems.
5. GitHub repository link is configured and verified.
