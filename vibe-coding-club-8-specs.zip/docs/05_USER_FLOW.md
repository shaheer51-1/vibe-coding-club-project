# 05_USER_FLOW.md - User Journeys & State Machine Architecture

## 1. Primary User Journey: Vibe Coding Club Deliverable Submission
This journey models how a 1st/2nd semester student uses VibeCraft to review, customize, verify, and submit their complete assignment before the Sunday evening deadline.

```
+------------------------------------------------------------------------+
| 1. ENTRY & ORIENTATION                                                 |
| - Student lands on VibeCraft                                           |
| - Sees club banner: "Vibe Coding Club Task Deliverables"               |
| - Inspects the 8 required markdown documents overview                  |
+-----------------------------------+------------------------------------+
                                    |
                                    v
+------------------------------------------------------------------------+
| 2. REVIEWING SPECIFICATIONS                                            |
| - Browses files 01 through 08 in the Spec Hub                          |
| - Switches between Rendered Markdown and Raw Source                    |
| - Uses the built-in search to locate acceptance criteria              |
+-----------------------------------+------------------------------------+
                                    |
                                    v
+------------------------------------------------------------------------+
| 3. INTERACTIVE SYSTEM VERIFICATION (THE LIVE PROJECT)                  |
| - Enters "Interactive Studio Workbench"                                |
| - Steps through User Flow Simulator to test branching state logic       |
| - Pings Architecture Topology nodes to verify component responsiveness|
| - Runs Test Harness to verify all unit & prompt regression gates pass |
+-----------------------------------+------------------------------------+
                                    |
                                    v
+------------------------------------------------------------------------+
| 4. EXPORTING DELIVERABLES                                              |
| - Clicks "Export All 8 Files (.ZIP)" to download complete bundle       |
| - Or downloads individual .md files directly to their project directory|
+-----------------------------------+------------------------------------+
                                    |
                                    v
+------------------------------------------------------------------------+
| 5. GITHUB REPO SETUP & HAND-OFF                                        |
| - Navigates to "GitHub Submission Suite"                               |
| - Enters GitHub handle and repository name                             |
| - Copies copy-paste CLI bash script to push commit to GitHub           |
| - Verifies deliverable checklist (8 .md files + working code + link)   |
+------------------------------------------------------------------------+
```

---

## 2. Finite State Machine: User Flow Simulator
The interactive simulator within VibeCraft models the 5 states of an AI-assisted vibe coding cycle:

```
[INIT: Spec Drafting]
       |
       | (Action: Generate Architecture & PRD)
       v
[STATE 1: Prompt Execution]
       |
       |--> [Decision: Hallucination or Syntax Error?]
       |          |
       |          +--- Yes ---> [STATE 2A: Spec Refinement / Constrain Context]
       |                               |
       |                               +--- (Re-prompt AI with 04_DESIGN & 03_ARCH)
       |                               |
       |          +--- No  ---> [STATE 2B: Compilation & Build Verification]
       v                               |
[STATE 3: Automated Testing & QA] <----+
       |
       |--> [Decision: Test Gates Pass?]
       |          |
       |          +--- Fail ---> [STATE 2A: Spec Refinement]
       |          |
       |          +--- Pass ---> [STATE 4: Production Deployment & GitHub Push]
       v
[STATE 5: Submission Complete]
```

---

## 3. Decision Tree: Edge Cases & Error Recovery

### Case A: Student has a custom project idea instead of the default template
- **Trigger**: Student wants to use the 8-markdown methodology for their personal semester project (e.g., Campus Lost & Found, Algorithm Visualizer).
- **System Action**: Student clicks "Edit Document" on any of the 8 files. VibeCraft saves their custom edits to `localStorage`. The student can download their personalized 8 markdown files. A "Restore Default Club Templates" button is provided to reset safely.

### Case B: Clipboard API permission is restricted in browser
- **Trigger**: Browser blocks `navigator.clipboard.writeText`.
- **System Action**: VibeCraft catches the exception, displays an inline selectable textarea modal, and triggers automatic text selection for manual `Ctrl+C` / `Cmd+C` copying.

### Case C: Student is missing local Git installation
- **Trigger**: Student asks how to upload to GitHub without terminal Git.
- **System Action**: The GitHub submission tab provides step-by-step instructions for uploading files directly via GitHub.com Web UI (Drag-and-Drop) as well as the CLI command sequence.
