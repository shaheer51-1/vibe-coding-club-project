# 02_FEATURES.md - Feature Specifications & User Personas

## 1. User Personas

### Persona A: Amir (1st Semester CS Club Member)
- **Profile**: Learning foundational programming (C/Python/JS). Eager to use AI tools for homework and club hackathons, but overwhelmed when Cursor generates 20 files that fail to compile.
- **Goal**: Needs a clear, guided framework where specifications constrain the AI, preventing chaotic spaghetti code.
- **Pain Point**: Spends 3 hours prompting and ends up with a broken app that doesn't fulfill club requirements.

### Persona B: Sarah (2nd Semester Web Developer & Club Peer Mentor)
- **Profile**: Understands React fundamentals and Git. Wants to build complete portfolio projects using modern vibe coding techniques.
- **Goal**: Rapidly scaffold production-ready apps with complete architectural docs, design systems, and testing harnesses.
- **Pain Point**: Missing standard documentation templates; often forgets user flows or test cases.

### Persona C: Dr. / Club Lead Tariq (Vibe Coding Club Organizer)
- **Profile**: Evaluates student deliverables for Sunday evening deadlines.
- **Goal**: Easily inspect the 8 markdown files, verify a live functioning project, and confirm git repository hygiene.
- **Pain Point**: Students submit raw code without any markdown documentation or architectural justification.

---

## 2. Feature Prioritization Matrix

### Priority 0: Essential Must-Haves (P0 - MVP Core)
- **F-01: 8-Markdown Specification Hub**:
  - Full display of all 8 markdown files (`01_OVERVIEW.md` through `08_TESTING_PLAN.md`).
  - Search, quick file switcher, raw markdown viewing, and syntax formatted rendering.
  - One-click copy to clipboard with instant visual feedback.
  - Complete `.zip` archive generator and individual `.md` file download.
- **F-02: Live Spec-Driven Interactive Modules**:
  - Module 1: **Interactive Architecture Topology** (live component visualizer with dependency flow and system health).
  - Module 2: **Interactive User Flow State Machine** (step-by-step journey simulator with branching choices).
  - Module 3: **Design System Token Playground** (color token contrast checker, typography scale previewer, spacing math calculator).
  - Module 4: **Sprint Roadmap & Kanban Board** (dynamic task movement, milestone completion rate).
  - Module 5: **Unit Economics & Token Cost Calculator** (live calculations for API tokens, prompt overhead, cost per user).
  - Module 6: **Automated Testing Runner** (live execution of Unit, Integration, and Spec tests with pass/fail telemetry).
- **F-03: GitHub Submission & Hand-Off Suite**:
  - Student repository configuration form (username, repo name, commit message).
  - Generated CLI script commands (`git init`, `git add .`, `git commit`, `git remote`, `git push`).
  - Readiness validator verifying all 8 deliverables before submission.

### Priority 1: High Value Enhancements (P1)
- **F-04: Markdown Live Editor**:
  - In-app text editor allowing students to customize any of the 8 specification files for their own custom project ideas.
  - Reset to default button.
- **F-05: AI Spec Prompt Generator**:
  - Guided prompt builder that formats high-density prompts for Claude/Cursor/Gemini based on the 8-markdown methodology.

### Priority 2: Delighters (P2)
- **F-06: Vibe Coding Club Session Notes & Cheat Sheet**:
  - Quick reference guide summarizing Andrej Karpathy's principles, context engineering best practices, and prompt antipatterns.

---

## 3. Detailed Acceptance Criteria (Gherkin Syntax)

### Feature F-01: 8-Markdown Hub & Export
```gherkin
Scenario: Club member exports all 8 markdown deliverables
  Given the student is viewing the 8-Markdown Documentation Hub
  When the student clicks "Export All 8 Files (.ZIP)"
  Then a zip archive named "vibe-coding-8-specs.zip" is generated containing:
    | 01_OVERVIEW.md |
    | 02_FEATURES.md |
    | 03_ARCHITECTURE.md |
    | 04_DESIGN.md |
    | 05_USER_FLOW.md |
    | 06_ROADMAP.md |
    | 07_BUSINESS_MODEL.md |
    | 08_TESTING_PLAN.md |
  And the student receives a confirmation toast notification within 200ms.
```

### Feature F-02: Live Test Harness Execution
```gherkin
Scenario: Student executes automated test suite
  Given the student is on the "Testing Plan & Quality Gates" workbench
  When the student clicks "Run All Test Suites"
  Then the test runner executes all unit, integration, and prompt regression checks
  And updates the test counter showing passed / total tests
  And displays individual execution latency and assertion messages.
```

### Feature F-03: GitHub Upload Verification
```gherkin
Scenario: Student configures GitHub submission
  Given the student enters GitHub username "shaheer-khalid" and repo "vibe-coding-project"
  When the student checks the deliverable checklist
  Then the ready-to-run Git shell commands update dynamically with the exact clone and push commands
  And provides a direct clickable link to verify the target repository.
```
