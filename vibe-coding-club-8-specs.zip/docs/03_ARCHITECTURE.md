# 03_ARCHITECTURE.md - System Architecture & Technical Specifications

## 1. High-Level Technology Stack
- **Framework**: React 19 (Functional components, custom hooks, strictly typed)
- **Bundler & Dev Server**: Vite 8 with ESNext module resolution
- **Styling**: Tailwind CSS v4 via `@tailwindcss/vite`
- **Iconography**: Lucide React
- **Client Storage & State**: Pure React reactive state + LocalStorage persistence
- **File Archiving**: JSZip (client-side in-memory zip packaging)
- **Deployment Platform**: Google Cloud Run / AI Studio container environment on Port 3000

---

## 2. Architectural Diagram

```
+-------------------------------------------------------------------------+
|                              USER INTERFACE                             |
|  +---------------------+  +--------------------+  +------------------+  |
|  |  8-Doc Spec Hub     |  | Interactive Studio |  | GitHub Hand-off  |  |
|  |  - Markdown Reader  |  | - Flow Simulator   |  | - CLI Script Gen |  |
|  |  - Raw / Formatted  |  | - Arch Topology    |  | - Checklist      |  |
|  |  - Zip & Export     |  | - Design Tokens    |  | - Repo Tester    |  |
|  |  - In-browser Edit  |  | - Unit Econ Calc   |  |                  |  |
|  |                     |  | - Test Harness     |  |                  |  |
|  +---------------------+  +--------------------+  +------------------+  |
+------------------------------------+------------------------------------+
                                     |
                                     v
+-------------------------------------------------------------------------+
|                         APPLICATION STATE & HOOKS                       |
|  - useSpecDocuments (syncs 8 default markdown files + custom user edits)|
|  - useTestRunner (executes real assertion suites in-browser)            |
|  - useUserFlowSimulation (finite state machine for user journeys)       |
|  - useEconomicsCalculator (computes prompt token burn rates & costs)    |
|  - useKanbanBoard (manages roadmap cards, sprints, status transitions)  |
+------------------------------------+------------------------------------+
                                     |
                                     v
+-------------------------------------------------------------------------+
|                         UTILITIES & CLIENT ENGINE                       |
|  - markdownBundler.ts (JSZip in-memory generation for .zip downloads)   |
|  - testEngine.ts (assertion runner, latency timers, test metrics)       |
|  - specTemplates.ts (embedded canonical versions of all 8 documents)   |
|  - gitHelper.ts (CLI bash generator for student repos)                  |
+-------------------------------------------------------------------------+
```

---

## 3. Component Hierarchy
```
src/
├── App.tsx                     # Main application layout, navigation & active view router
├── components/
│   ├── Header.tsx              # Unboxed brand title, club badge, view toggle, quick zip action
│   ├── Navigation.tsx          # Tabbed segmented navigation for 3 primary workflows
│   ├── SpecHub/
│   │   ├── SpecExplorer.tsx    # Sidebar selector for the 8 documents + search & stats
│   │   ├── MarkdownViewer.tsx  # Formatted vs raw markdown viewer with copy & file download
│   │   └── MarkdownEditor.tsx  # In-browser live document editor with diff / restore
│   ├── Workbench/
│   │   ├── FlowSimulator.tsx   # Interactive step-by-step state machine with decision trees
│   │   ├── ArchTopology.tsx    # Interactive architecture canvas with system nodes & ping
│   │   ├── DesignInspector.tsx # Real-time design system tokens, typography & contrast tool
│   │   ├── RoadmapBoard.tsx    # Interactive Kanban board for Sprint 1-4 deliverables
│   │   ├── EconomicsCalc.tsx   # Unit economics & prompt token cost estimator
│   │   └── TestHarness.tsx     # Runnable automated test suite with passing assertions
│   ├── GitHubHandOff/
│   │   ├── SubmissionCard.tsx  # Student GitHub repo configuration & direct link tester
│   │   ├── ScriptGenerator.tsx # Dynamic Bash command runner copy block
│   │   └── Checklist.tsx       # Live status of 8 deliverables + repo validation
│   └── ClubGuide/
│       └── WorkflowGuide.tsx   # Visual infographic & cheat sheet of the 8-markdown method
├── data/
│   └── defaultSpecs.ts         # High-fidelity text source for all 8 markdown documents
└── utils/
    ├── zipExport.ts            # JSZip download helper
    └── testSuites.ts           # Runnable test specs matching 08_TESTING_PLAN.md
```

---

## 4. State Management Lifecycle
1. **Initial Mount**: `useSpecDocuments` loads the 8 canonical markdown documents. If the user previously made edits in `localStorage`, those drafts are merged; otherwise default club templates are rendered.
2. **Tab Routing**: `activeTab` switches seamlessly between:
   - `specs`: The 8 Markdown Documentation Explorer
   - `workbench`: The Live Interactive Engineering Modules
   - `github`: Submission & GitHub Repo Generator
   - `guide`: The Vibe Coding Workflow Methodology Guide
3. **Execution Pipeline**:
   - The test harness runs asynchronously on client worker tick, computing actual assertion matches, latency in milliseconds, and status flags (`passed`, `failed`, `running`).
   - The economic calculator recomputes immediately upon input modifications without network lag.

---

## 5. Security & Invariant Rules
- **Pure Client Safety**: No credentials, tokens, or private data are transmitted to external servers.
- **Content Sanitization**: Markdown is parsed and escaped safely to prevent XSS.
- **Fail-Safe Offline Mode**: Fully operational even if network is disconnected.
